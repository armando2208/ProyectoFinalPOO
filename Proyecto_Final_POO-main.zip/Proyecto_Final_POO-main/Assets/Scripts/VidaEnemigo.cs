﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para darle vida independiente a cada uno de nuestros enemigos
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VidaEnemigo : MonoBehaviour
{
    [SerializeField]
    private int vida=3;

    public int Vida
    {

        get //Solo leera la vida que tiene el enemigo
        {
            return vida;
        }

        set //Podra leer la vida que tiene y hacerle cambios como el restar la vida
        {
            if (vida <= 1) //Cuando la vida del enemigo llegue a 0 se destruira de escena
            {
                Destroy(this.gameObject);
            }
            vida = value;
        }

    }
}
