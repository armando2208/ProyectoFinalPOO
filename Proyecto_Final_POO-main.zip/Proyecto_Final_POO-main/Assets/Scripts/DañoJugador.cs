﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para darle comportamiento cuando el Player reciba daño
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DañoJugador : MonoBehaviour
{
    VidaJugador dañoColor;

    void Start()
    {
        dañoColor = GameObject.FindGameObjectWithTag("Player").GetComponent<VidaJugador>(); //dañoColor buscara al objeto con el Tag "Player" y traera su componente VidaJugador
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag=="Player") //Cuando colisione con el objeto del Tag "Player" se iniciara la corrutina 
        {
            dañoColor.TomarDaño(GetComponentInParent<Daño>().daño);
            StartCoroutine(dañoColor.CambioColor());
        }
    }
}
