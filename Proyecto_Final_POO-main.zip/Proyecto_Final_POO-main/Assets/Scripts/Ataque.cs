﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para generar el ataque del Player desde la punta de su arma
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ataque : MonoBehaviour
{
    public Rigidbody2D bala; //Varaible publica de tipo Rigidbody2D para guardar la bala
    public Rigidbody2D balaLeft; //Varaible publica de tipo Rigidbody2D para guardar la bala izquierda
    public Transform PuntaArma; //Variable publica de tipo Transform para guardar la posicion de la punta del arma
    public Transform PuntaArmaLeft; //Variable publica de tipo Transform para guardar la posicion de la punta del arma izquierda

    public void CreacionBala()
    {
        if (GetComponent<SpriteRenderer>().flipX == true) //Cuando el flipX del SpriteRenderer sea verdadero ocurriran las siguientes acciones:
        {
            Rigidbody2D DireccionBalaLeft = Instantiate(bala) as Rigidbody2D;                                                                              
            DireccionBalaLeft.transform.position = PuntaArmaLeft.position; //Se activara el disparo del arma hacia la izquierda desde la 
            DireccionBalaLeft.AddForce(PuntaArmaLeft.right * -700); // la posicion de la punta del arma izquierda con una fuerza de -700
        }
        if (GetComponent<SpriteRenderer>().flipX == false) //Cuando el flipX del SpriteRenderer sea falso ocurriran las siguientes acciones:
        {
            Rigidbody2D DireccionBala = Instantiate(bala) as Rigidbody2D;
            DireccionBala.transform.position = PuntaArma.position; //Se activara el disparo del arma hacia la derecha desde la    
            DireccionBala.AddForce(PuntaArma.right * 700); // la posicion de la punta del arma derecha con una fuerza de 700
        }
    }

   
}
