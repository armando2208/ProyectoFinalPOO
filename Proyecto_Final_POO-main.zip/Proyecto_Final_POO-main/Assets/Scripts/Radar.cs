﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para que nuestro enemigo persiga al Player cuando se acerque a su radar y active su animacion correspondiente
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Radar : MonoBehaviour
{   
    private void OnTriggerEnter2D(Collider2D collision) //Cuando entre en colision con el objeto de tag "Player" se activara la animacion de ataque del Ninja
                                                        
    {
        if (collision.gameObject.tag == "Player")
        {            
            GetComponentInParent<Animator>().Play("Attack_Ninja");
            GetComponentInParent<PropiedadesEnemigo>().iniciarPersecucion = true; // Iniciara la persecucion del enemigo hacia nuestro Player 
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")//Cuando deje de colisionar con el objeto de tag "Player" se desactivara la animacion de ataque y estara en la animacion idle                                                
        {
             GetComponentInParent<Animator>().Play("idle_Ninja");
             GetComponentInParent<PropiedadesEnemigo>().iniciarPersecucion = false; // Se desactivara la persecucion del enemigo 
        }
    }
}
