﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo:Este script se utilizara para darle movimiento al Player con sus respectivas animaciones
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimientoPlayer : MonoBehaviour
{
    Rigidbody2D fisicasRB2D; // Variable de tipo Rigidbody2D con el nombre de fisicasRBD2

    public float fuerzaSaltoPersonaje; //Variable publica de tipo float para la fuerza de salto del personaje

    float velocidadX; //Variable publica de tipo float para la velocidad en X

    int LimiteSaltos = 2; //Variable publica de tipo int para limitar los saltos del personaje

    int SaltosRealizados; //Variable publica de tipo int para llevar un conteo de los saltos realizados

    // Start is called before the first frame update
    void Start()
    {
        fisicasRB2D = GetComponent<Rigidbody2D>(); // fisicasRBD2 traera su componente Rigidbody2D
        fuerzaSaltoPersonaje = 5.0f; // La fuerza de salto sera de 5
        SaltosRealizados = 0; //Los saltos realizados seran 0 
    }

    // Update is called once per frame
    void Update()
    {
        velocidadX = 0f;

        if (Input.GetKey(KeyCode.D)) //Cuando se presione la tecla "D" ocurrira lo siguiente:
        {
            if (GetComponent<SpriteRenderer>().flipX == true) //Si flipX es verdadero se convertira a falso y activara la animacion de caminar con una velocidad en X de 5
            {
                GetComponent<SpriteRenderer>().flipX = false;
            }
            GetComponent<Animator>().SetBool("Walk", true);
            velocidadX = 5f;
        }

        if (Input.GetKey(KeyCode.A)) //Cuando se presione la tecla "A" ocurrira lo siguiente:
        {
            if (GetComponent<SpriteRenderer>().flipX == false) //Si flipX es falso se convertira a verdadero y activara la animacion de caminar con una velocidad en X de -5
            {
                GetComponent<SpriteRenderer>().flipX = true;
            }
            GetComponent<Animator>().SetBool("Walk", true);
            velocidadX = -5f;
        }

        transform.Translate(velocidadX * Time.deltaTime, 0f, 0f);

        if (velocidadX == 0f) //Si la velocidad en X es 0 se desactivara la animacion de caminar
        {
            GetComponent<Animator>().SetBool("Walk", false);
        }

        if (Input.GetKeyDown(KeyCode.Space)) //Cuando se presione la tecla "Barra espaciadora" ocurrira lo siguiente:
        {
            if (SaltosRealizados < LimiteSaltos) // Si los saltos realizados son menores a el limite activara esto:
            {
                fisicasRB2D.AddForce(Vector2.up * fuerzaSaltoPersonaje, ForceMode2D.Impulse); //Le agregara fuerza e impulso para que pueda realizar el salto
                SaltosRealizados++; //Cada que se presione la tecla de "Barra espaciadora" ira aumentando +1 en saltos realizados hasta llegar al limite
            }
        }
        EjecutarAtaque(); // Se ejecutara la funcion de EjecutarAtaque
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Suelo") //Cuando el personaje toque el objeto con el Tag "Suelo" el contador de saltos realizados vuelve a ser 0 para que pueda volver
                                               // volver a saltar
        {
            SaltosRealizados = 0;
        }
    }

    void EjecutarAtaque()
    {
        if (Input.GetMouseButtonDown(0)) //Cuando se presione el boton izquierdo del mouse ocurrira lo siguiente:
        {
            GetComponent<Animator>().SetBool("Attack", true); //Se activara la animacion de ataque
        }

        if (Input.GetMouseButtonUp(0)) //Cuando se deje de presionar el boton izquierdo del mouse ocurrira lo siguiente:
        {
            GetComponent<Animator>().SetBool("Attack", false); // Se desactivara la animacion de ataque
        }
    }
}





