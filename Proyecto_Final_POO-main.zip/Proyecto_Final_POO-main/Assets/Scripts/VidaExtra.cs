﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo:Este script se utilizara para generar vida extra al Player
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VidaExtra : MonoBehaviour
{
    VidaJugador vidaJugador; //Llamamos a la vidaJugador del script VidaJugador para generar cambios

    private int ActualizacionVida = 20; //Variable privada de tipo int llamada ActualizacionVida que contara con un valor de 20

    SpriteRenderer spriteVida; //Variable de tipo SpriteRender para guardar el SpriteRender de la vida

    private void Start()
    {
        spriteVida = GameObject.Find("Power Up").GetComponent<SpriteRenderer>(); //Busca al objeto llamado "Power Up" y le asigna el componente SpriteRenderer
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")                      //Si colisiona con el objeto con el Tag "Player" sucedera las siguientes acciones                                                                    
        {
            VidaJugador.vidaJugador = VidaJugador.vidaJugador + ActualizacionVida; //La vida del jugador se le sumara la ActualizacionVida que en este caso es 20
            ActualizacionVida = 0; //Se actualizara el valor de ActualizacionVida a 0 para que ya no aumente mas vida
            Destroy(this.gameObject); //Se destruira el objeto "Power Up"
        }

    }
}
