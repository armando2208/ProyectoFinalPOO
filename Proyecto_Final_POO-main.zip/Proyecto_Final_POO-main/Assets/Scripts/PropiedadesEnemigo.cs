﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo:Este script utilizara las variables del ConstructorEnemigo para darle un objetivo al enemigo para atacarlo
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PropiedadesEnemigo : ConstructorEnemigo
{
    // Start is called before the first frame update
    void Start()
    {
        posicionInicial = GetComponent<Transform>(); //posicionInicial trae su componente Transform
        Objetivo = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>(); //Objetivo busca al GameObject con el Tag "Player" y trae su componente Transform
    }

    // Update is called once per frame
    void Update()
    {
        if (iniciarPersecucion==true) //Si iniciarPersecucion es igual a true se activara la funcion MoverA()
        {
            MoverA();
        }
    }
}
