﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para darle vida, daño a nuestro personaje
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class VidaJugador : MonoBehaviour
{
    public static int vidaJugador =100; //Variable publica static de tipo int para la vida del jugador
    public SpriteRenderer hurtColor; //Variable publica de tipo SpriteRenderer para el color de nuestro personaje

    [SerializeField]
    private int vidaActual; //Variable privada de tipo int para saber el nivel actual de nuestro personaje


    
    // Start is called before the first frame update
    void Start()
    {
        vidaJugador = 100; //Cuando se le da play al juego, el jugador comienza con una vida de 100
        hurtColor = GetComponent<SpriteRenderer>(); //hurColor busca y trae el componente SpriteRenderer de nuestro Player
        vidaActual = vidaJugador; // La vida actual es igual a la vida con la que comienza el jugador
    }

    // Update is called once per frame
    void Update()
    {
        vidaActual = vidaJugador;  
        if (vidaActual<=001) // si la vida del Player llega a 0, se desactiva de la escena actual y te lleva a la escena de End Game
        {
            gameObject.SetActive(false);
            SceneManager.LoadScene("End Game");

        }
        if (vidaActual >=100) // Es una condicionante para que la vida del personaje no pase de 100 cuando recolecte Power Ups
        {
            vidaJugador = 100;
        }
    }

    public void TomarDaño(int daño) // Cuando el Player reciba daño, a la vida del jugador se le disminuira el daño que le corresponda a cada enemigo 
    {
        vidaJugador = vidaJugador - daño;
    }
    

    public IEnumerator CambioColor()  //Cuando el Player reciba algun ataque cambiara a color Rojo posteriormente volvera a su color normal
    {
        hurtColor.color = Color.red;
        yield return new WaitForSeconds(0.5f);
        hurtColor.color = Color.white;

        yield return null;
    }
    
}
