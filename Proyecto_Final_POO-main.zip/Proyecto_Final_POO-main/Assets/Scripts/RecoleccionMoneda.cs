﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo:Este script se utilizara para recolectar las monedas y que se puedan intercambiar por mas vida para el Player
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecoleccionMoneda : MonoBehaviour
{
    public static int monedas=0; //Variable publica static de tipo int para las monedas recolectadas

    SpriteRenderer spriteMonedas; //Variable de tipo SpriteRender para guardar el SpriteRender de las monedas

    private int ActualizacionVida = 10; //Variable privada de tipo int para generarle mas vida al Player a traves de cierta cantidad de monedas

    // Start is called before the first frame update
    void Start()
    {
        monedas = 0; //Cuando empieza el juego el contador de monedas empieza en 0
        spriteMonedas = GameObject.FindGameObjectWithTag("Moneda").GetComponent<SpriteRenderer>(); //Busca al objeto llamado "Moneda" y le asigna el componente SpriteRenderer
    }

    // Update is called once per frame
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player") //Cuando colisone con el objeto del Tag Player ira sumando monedas y las monedas con las que ya haya colisonado se desactivaran
                                                  // de escena
        {
            monedas++;
            gameObject.SetActive(false);
            if (monedas == 10) //Cuando la cantidad de monedas recolectadas sea mayor a 3 se sumara el valor de ActualizacionVida a la Vida del jugador
            {
                VidaJugador.vidaJugador = VidaJugador.vidaJugador + ActualizacionVida;
                ActualizacionVida = 0;
                monedas = 0;
            }
        }
    }
    
}
