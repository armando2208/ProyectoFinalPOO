﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo:Este script se utilizara para cargar el nivel 1 del juego y para salir del juego de acuerdo al boton que se oprima
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuPrincipal : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void EscenaNivel1()
    {
        SceneManager.LoadScene("Nivel 1"); // Cuando se presione el boton de Play se cargara la escena "Nivel 1" y comenzara el juego
    }

    public void Exit()
    {
        Application.Quit(); //Cuando se presione el boton Exit se cerrara el juego
    }

    
}
