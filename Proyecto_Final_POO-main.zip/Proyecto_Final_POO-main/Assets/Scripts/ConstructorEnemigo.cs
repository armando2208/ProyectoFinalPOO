﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para declarar los comportamientos de nuestros enemigos
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConstructorEnemigo : MonoBehaviour
{
    public float velocidad; //Variable publica de tipo float para la velocidad
    public int Poder; //Variable publica de tipo int para el poder
    public Transform Objetivo; //Variable publica de tipo Transform para el objetivo
    public Transform posicionInicial; //Variable publica de tipo Transform para la posicion inicial
    public bool iniciarPersecucion = false; //Variable publica de tipo bool para iniciar la persecucion 

    public void MoverA()
    {
        posicionInicial.position = Vector3.MoveTowards(posicionInicial.position, Objetivo.position, velocidad * Time.deltaTime);
    }

    public void MoverA(Transform p)
    {
        p.position = Vector3.MoveTowards(p.position, Objetivo.position, velocidad * Time.deltaTime);
    }
}
