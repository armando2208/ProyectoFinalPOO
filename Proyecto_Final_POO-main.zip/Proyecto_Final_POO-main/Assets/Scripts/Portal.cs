﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para controlar la escena que se cargara cuando colisione con cierto objeto
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Portal : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player") //Cuando haya una colision con un objeto con el tag "Player" se cargara la escena
        {
            SceneManager.LoadScene("Winner");
        }
    }
}
