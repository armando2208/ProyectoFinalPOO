﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo:Este script se utilizara para mostrar la vida del Player en la escena de juego
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InterfazVida : MonoBehaviour
{
    public Text vidaTxt; //Variable publica de tipo Text para almacenar la vida del Player en forma de Texto
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        vidaTxt.text = VidaJugador.vidaJugador.ToString("000"); // Convertira la vida del jugador a formato de texto y lo mostrara en la escena de juego
    }
}
