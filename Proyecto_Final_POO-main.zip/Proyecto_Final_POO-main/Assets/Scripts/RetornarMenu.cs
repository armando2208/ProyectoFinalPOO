﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para controlar las acciones de los botones de la escena End Game
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RetornarMenu : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void CargarMenu()
    {
        SceneManager.LoadScene("Menu"); //Cuando se presione el boton Menu se caraga la escena llamada Menu
    }

    public void Exit()
    {
        Application.Quit(); //Cuando se presione el boton Exit se cerrara el juego
    }

}
