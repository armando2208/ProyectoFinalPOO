﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo: Codigo para restarle vida a los enemigos con el proyectil del Player
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColisionBala : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag=="Enemigo") // Cuando colisione la bala con el objeto que tiene el Tag "Enemigo" en el componente de su vida le restara 1 vida
                                                 // Y se destruira la bala cuando colisione con el enemigo
        {
            collision.gameObject.GetComponent<VidaEnemigo>().Vida--;
            Destroy(this.gameObject);
        }
        Destroy(gameObject, 1f);
    }
}
