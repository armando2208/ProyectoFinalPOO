﻿/*
Nombre del desarrollador: Armando Michel Flores Sanchez
Asignatura: Programacion Orientada a Objetos
Profesor: Josue Israel Rivas Diaz
Descripcion general del codigo:Este script se utilizara para mostrar las monedas que ha recogido el Player en la escena de juego
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InterfazMonedas : MonoBehaviour
{
    public Text monedasTxt; //Variable publica de tipo Text para almacenar las monedas recolectas por el Player en forma de Texto

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        monedasTxt.text = RecoleccionMoneda.monedas.ToString("00"); // Convertira las monedas recolectadas a formato de texto y lo mostrara en la escena de juego
    }
}
